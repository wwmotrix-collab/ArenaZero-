# Arena Zero — Firebase

Esta versão troca a ideia de SQL/Postgres por Firebase:

- Firebase Hosting para publicar o app.
- Firestore para arenas, quadras, esportes, eventos, jogadores, participações, resultados, XP e MMR.
- Firebase Auth anônimo no MVP, podendo evoluir para telefone/OTP.
- Storage para logos e imagens das arenas.

## 1. Criar projeto

1. Crie um projeto no Firebase Console.
2. Ative Firestore Database.
3. Ative Authentication e habilite Anonymous no MVP.
4. Ative Hosting.
5. Ative Storage se for usar imagens.

## 2. Configurar app

Edite `js/config.js` e substitua:

```js
firebase: {
  apiKey: 'COLE_SUA_API_KEY',
  authDomain: 'SEU_PROJETO.firebaseapp.com',
  projectId: 'SEU_PROJETO',
  storageBucket: 'SEU_PROJETO.appspot.com',
  messagingSenderId: 'SEU_SENDER_ID',
  appId: 'SEU_APP_ID'
}
```

## 3. Publicar regras e índices

```bash
npm install -g firebase-tools
firebase login
cp .firebaserc.example .firebaserc
# edite .firebaserc com o ID real do projeto
firebase deploy --only firestore:rules,firestore:indexes,storage
```

## 4. Publicar app

```bash
firebase deploy --only hosting
```

## 5. Coleções Firestore

### arenas
```js
{
  name: 'Arena São Paulo',
  ownerUid: 'uid_do_dono',
  city: 'São Paulo',
  active: true,
  createdAt,
  updatedAt
}
```

### courts
```js
{
  arenaId: 'id_arena',
  name: 'Quadra A',
  sports: ['futebol_7'],
  active: true
}
```

### sports
```js
{
  name: 'Futebol 7',
  emoji: '⚽',
  playersPerTeam: 7,
  teamsCount: 2,
  reservePercent: 30,
  durationMin: 90
}
```

### events
```js
{
  arenaId,
  courtId,
  sportId,
  sportName,
  startsAt,
  durationMin,
  playersPerTeam,
  teamsCount,
  reservePercent,
  confirmedCount,
  status: 'open',
  inviteToken,
  createdAt,
  updatedAt
}
```

### players
```js
{
  name,
  phone,
  xpTotal: 0,
  mmr: 1000,
  level: 1,
  streak: 0,
  createdAt,
  updatedAt
}
```

### participations
```js
{
  eventId,
  playerId,
  playerName,
  phone,
  team: 'team_1' | 'team_2' | 'reserve',
  position,
  status: 'confirmed',
  createdAt
}
```

### results
```js
{
  eventId,
  scoreTeam1,
  scoreTeam2,
  winner: 'team_1' | 'team_2' | 'draw',
  status: 'pending' | 'validated' | 'contested',
  createdBy,
  createdAt,
  validatedAt
}
```

### xp_logs e mmr_logs
Devem ser escritos por backend seguro depois, via Cloud Functions. No MVP, as regras bloqueiam escrita direta nessas coleções.

## Próxima etapa técnica

Criar Cloud Functions para:

1. validar resultado;
2. distribuir XP;
3. calcular MMR;
4. registrar logs imutáveis;
5. atualizar ranking.
