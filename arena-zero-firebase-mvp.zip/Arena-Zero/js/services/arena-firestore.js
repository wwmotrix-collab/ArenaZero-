import { db, isConfigured, serverTimestamp } from './firebase.js';
import {
  addDoc,
  collection,
  doc,
  getDoc,
  getDocs,
  increment,
  limit,
  orderBy,
  query,
  setDoc,
  updateDoc,
  where
} from 'https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js';

function cleanPhone(phone) {
  return String(phone || '').replace(/\D/g, '');
}

function playerIdFromPhone(phone) {
  const cleaned = cleanPhone(phone);
  return cleaned ? `phone_${cleaned}` : `guest_${Date.now()}`;
}

function pickTeam(position, playersPerTeam) {
  if (position <= playersPerTeam) return 'team_1';
  if (position <= playersPerTeam * 2) return 'team_2';
  return 'reserve';
}

async function upsertPlayer({ name, phone }) {
  if (!isConfigured) return null;
  const id = playerIdFromPhone(phone);
  const ref = doc(db, 'players', id);
  const snap = await getDoc(ref);
  const payload = {
    name: String(name || 'Jogador').trim(),
    phone: cleanPhone(phone),
    updatedAt: serverTimestamp()
  };
  if (!snap.exists()) {
    await setDoc(ref, {
      ...payload,
      xpTotal: 0,
      mmr: 1000,
      level: 1,
      streak: 0,
      createdAt: serverTimestamp()
    });
  } else {
    await updateDoc(ref, payload);
  }
  return id;
}

async function createEvent(event) {
  if (!isConfigured) return null;
  const ref = await addDoc(collection(db, 'events'), {
    arenaId: event.arenaId || 'demo_arena',
    courtId: event.courtId || 'quadra_a',
    sportId: event.sportId || 'futebol_7',
    sportName: event.sportName || 'Futebol 7',
    startsAt: event.startsAt || null,
    durationMin: event.durationMin || 90,
    playersPerTeam: event.playersPerTeam || 7,
    teamsCount: event.teamsCount || 2,
    reservePercent: event.reservePercent || 30,
    confirmedCount: 0,
    status: 'open',
    inviteToken: event.inviteToken || crypto.randomUUID(),
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  });
  return ref.id;
}

async function joinEvent({ eventId, name, phone, playersPerTeam = 7, currentCount = 0 }) {
  if (!isConfigured) return { offline: true };
  const playerId = await upsertPlayer({ name, phone });
  const position = currentCount + 1;
  const team = pickTeam(position, playersPerTeam);
  const participationRef = await addDoc(collection(db, 'participations'), {
    eventId,
    playerId,
    playerName: String(name || 'Jogador').trim(),
    phone: cleanPhone(phone),
    team,
    position,
    status: 'confirmed',
    createdAt: serverTimestamp()
  });
  await updateDoc(doc(db, 'events', eventId), {
    confirmedCount: increment(1),
    updatedAt: serverTimestamp()
  });
  return { id: participationRef.id, playerId, team, position };
}

async function joinDemoEvent({ name, phone, sport, currentCount }) {
  if (!isConfigured) return { offline: true };
  let eventId = localStorage.getItem('arenaZeroDemoEventId');
  if (!eventId) {
    eventId = await createEvent({
      sportId: String(sport?.n || 'futebol_7').toLowerCase().replace(/\s+/g, '_'),
      sportName: sport?.n || 'Futebol 7',
      durationMin: sport?.dur || 90,
      playersPerTeam: sport?.ppt || 7,
      teamsCount: sport?.tc || 2,
      reservePercent: sport?.rp || 30
    });
    localStorage.setItem('arenaZeroDemoEventId', eventId);
  }
  return joinEvent({
    eventId,
    name,
    phone,
    playersPerTeam: sport?.ppt || 7,
    currentCount: Number(currentCount || 0)
  });
}

async function listRanking(max = 20) {
  if (!isConfigured) return [];
  const q = query(collection(db, 'players'), orderBy('xpTotal', 'desc'), orderBy('mmr', 'desc'), limit(max));
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
}

window.ArenaZeroFirestore = {
  upsertPlayer,
  createEvent,
  joinEvent,
  joinDemoEvent,
  listRanking
};

export { upsertPlayer, createEvent, joinEvent, joinDemoEvent, listRanking };
