const ARENA_ZERO_CONFIG = {
  appName: 'Arena Zero',
  version: '0.2.0-firebase',
  backend: 'firebase',
  demoMode: true,
  baseInviteUrl: 'https://arena-zero.web.app/partida/',
  firebase: {
    apiKey: 'COLE_SUA_API_KEY',
    authDomain: 'SEU_PROJETO.firebaseapp.com',
    projectId: 'SEU_PROJETO',
    storageBucket: 'SEU_PROJETO.appspot.com',
    messagingSenderId: 'SEU_SENDER_ID',
    appId: 'SEU_APP_ID'
  },
  xp: {
    win: 10,
    loss: 6,
    draw: 8,
    streak3: 2,
    streak5: 5,
    streak7: 8,
    bestPlayerBase: 5
  },
  mmr: {
    default: 1000,
    kFactor: 32
  }
};

const APP_CONFIG = ARENA_ZERO_CONFIG;
window.ARENA_ZERO_CONFIG = ARENA_ZERO_CONFIG;
console.log('[Arena Zero] Config carregado:', ARENA_ZERO_CONFIG);
