# Configuração Arena Zero

## Backend atual

Esta versão usa Firebase.

Arquivos principais:

- `firebase.json`
- `firestore.rules`
- `firestore.indexes.json`
- `storage.rules`
- `js/config.js`
- `js/services/firebase.js`
- `js/services/arena-firestore.js`
- `docs/FIREBASE.md`

## Passos

1. Criar projeto no Firebase.
2. Ativar Firestore.
3. Ativar Authentication Anonymous.
4. Editar `js/config.js` com as credenciais do app web.
5. Rodar:

```bash
firebase deploy --only firestore:rules,firestore:indexes,storage,hosting
```

## Observação

O arquivo SQL antigo ficou em `sql/arena_zero_schema.sql` só como referência histórica. Para Firebase, usar as coleções descritas em `docs/FIREBASE.md`.
