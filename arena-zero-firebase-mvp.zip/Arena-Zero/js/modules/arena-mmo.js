(function(){
  function expectedScore(playerMmr, opponentMmr){
    return 1 / (1 + Math.pow(10, (opponentMmr - playerMmr) / 400));
  }

  function nextMmr(current, opponentAvg, result, kFactor){
    var expected = expectedScore(current, opponentAvg);
    return Math.round(current + (kFactor || 32) * (result - expected));
  }

  function bestPlayerXp(streak){
    return Math.round(5 * (1 + 0.1 * Math.log((streak || 0) + 1)));
  }

  function matchXp(result, streak, isBestPlayer){
    var xp = result === 'win' ? 10 : result === 'draw' ? 8 : 6;
    if(streak >= 3) xp += 2;
    if(streak >= 5) xp += 5;
    if(streak >= 7) xp += 8;
    if(isBestPlayer) xp += bestPlayerXp(streak);
    return xp;
  }

  window.ArenaZeroMMO = { expectedScore: expectedScore, nextMmr: nextMmr, matchXp: matchXp, bestPlayerXp: bestPlayerXp };
})();
