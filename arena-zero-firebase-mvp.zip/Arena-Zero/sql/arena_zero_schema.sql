-- Arena Zero MVP — schema PostgreSQL/Neon/Supabase-compatible
-- Rode em um banco Postgres limpo. Se usar PocketBase, este SQL serve como mapa de coleções.

create extension if not exists pgcrypto;

create table if not exists arenas (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text,
  address text,
  created_at timestamptz not null default now()
);

create table if not exists courts (
  id uuid primary key default gen_random_uuid(),
  arena_id uuid not null references arenas(id) on delete cascade,
  name text not null,
  sports text[] not null default '{}',
  active boolean not null default true
);

create table if not exists sports (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  emoji text default '⚽',
  players_per_team int not null default 7,
  teams_count int not null default 2,
  reserve_percent int not null default 30,
  duration_minutes int not null default 90
);

create table if not exists players (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text not null unique,
  xp_total int not null default 0,
  level int not null default 1,
  mmr int not null default 1000,
  streak_wins int not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists events (
  id uuid primary key default gen_random_uuid(),
  arena_id uuid not null references arenas(id) on delete cascade,
  court_id uuid references courts(id),
  sport_id uuid references sports(id),
  captain_id uuid references players(id),
  starts_at timestamptz not null,
  duration_minutes int not null default 90,
  status text not null default 'open' check (status in ('open','formed','closed','result_pending','validated','cancelled')),
  invite_token text not null unique default encode(gen_random_bytes(16), 'hex'),
  paid boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists event_participants (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references events(id) on delete cascade,
  player_id uuid not null references players(id) on delete cascade,
  team int,
  role text not null default 'player' check (role in ('captain','player','reserve')),
  status text not null default 'confirmed' check (status in ('confirmed','cancelled','no_show')),
  joined_at timestamptz not null default now(),
  unique(event_id, player_id)
);

create table if not exists event_results (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null unique references events(id) on delete cascade,
  team_1_score int not null,
  team_2_score int not null,
  best_player_id uuid references players(id),
  reported_by uuid references players(id),
  status text not null default 'pending' check (status in ('pending','validated','contested')),
  created_at timestamptz not null default now(),
  validated_at timestamptz
);

create table if not exists xp_logs (
  id uuid primary key default gen_random_uuid(),
  event_id uuid references events(id) on delete cascade,
  player_id uuid references players(id) on delete cascade,
  amount int not null,
  reason text not null,
  created_at timestamptz not null default now()
);

create table if not exists mmr_logs (
  id uuid primary key default gen_random_uuid(),
  event_id uuid references events(id) on delete cascade,
  player_id uuid references players(id) on delete cascade,
  old_mmr int not null,
  new_mmr int not null,
  delta int not null,
  created_at timestamptz not null default now()
);

create table if not exists achievements (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  description text,
  xp_reward int not null default 0
);

create table if not exists player_achievements (
  player_id uuid references players(id) on delete cascade,
  achievement_id uuid references achievements(id) on delete cascade,
  unlocked_at timestamptz not null default now(),
  primary key(player_id, achievement_id)
);

insert into sports(name, emoji, players_per_team, teams_count, reserve_percent, duration_minutes) values
('Futebol 7','⚽',7,2,30,90),
('Futebol 5','⚽',5,2,30,60),
('Basquete','🏀',5,2,20,60),
('Vôlei','🏐',6,2,20,60),
('Padel','🎾',2,2,0,60)
on conflict (name) do nothing;

insert into achievements(code, name, description, xp_reward) values
('FIRST_MATCH','Primeira Partida','Confirmou a primeira partida na Arena Zero',10),
('HAT_TRICK_WINS','Sequência 3V','Três vitórias seguidas',2),
('CAPTAIN','Capitão','Criou ou liderou uma convocação',5),
('BEST_PLAYER','Best Player','Foi eleito destaque da partida',5)
on conflict (code) do nothing;
