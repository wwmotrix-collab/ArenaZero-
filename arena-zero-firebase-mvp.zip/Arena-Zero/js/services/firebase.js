import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.12.5/firebase-app.js';
import { getAuth, signInAnonymously, onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/10.12.5/firebase-auth.js';
import { getFirestore, serverTimestamp } from 'https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js';
import { getStorage } from 'https://www.gstatic.com/firebasejs/10.12.5/firebase-storage.js';

const cfg = window.ARENA_ZERO_CONFIG || {};
const firebaseConfig = cfg.firebase || {};
const isConfigured = Boolean(firebaseConfig.apiKey && !firebaseConfig.apiKey.includes('COLE_') && firebaseConfig.projectId && !firebaseConfig.projectId.includes('SEU_'));

let app = null;
let auth = null;
let db = null;
let storage = null;

if (isConfigured) {
  app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);
  storage = getStorage(app);
  signInAnonymously(auth).catch((err) => console.warn('[Arena Zero] Auth anônima falhou:', err));
  onAuthStateChanged(auth, (user) => {
    window.ArenaZeroFirebase.user = user || null;
  });
} else {
  console.warn('[Arena Zero] Firebase ainda não configurado. Edite js/config.js antes do deploy real.');
}

window.ArenaZeroFirebase = {
  app,
  auth,
  db,
  storage,
  isConfigured,
  serverTimestamp,
  user: null
};

export { app, auth, db, storage, isConfigured, serverTimestamp };
