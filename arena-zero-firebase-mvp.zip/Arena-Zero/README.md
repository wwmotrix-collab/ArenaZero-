# Arena Zero MVP

Arena Zero é a adaptação do motor do Pindura para reservas, convocação, eventos, ranking, XP e MMO social de arenas esportivas.

## Mudança promovida nesta versão

- Backend migrado para Firebase.
- Adicionado `firebase.json` para Hosting/Firestore/Storage.
- Adicionado `firestore.rules` com regras iniciais de segurança.
- Adicionado `firestore.indexes.json` para eventos, participações e ranking.
- Adicionado `storage.rules`.
- Atualizado `js/config.js` para receber credenciais Firebase.
- Adicionado `js/services/firebase.js` para inicialização do Firebase.
- Adicionado `js/services/arena-firestore.js` para eventos, jogadores, participação e ranking.
- Tela de confirmação agora tenta salvar a entrada no Firestore quando o Firebase estiver configurado.
- SQL mantido apenas como referência legada.

## Rodar local

Abra `index.html` direto no navegador para testar o modo demo visual.

Para testar Firebase de verdade, configure `js/config.js` e rode com um servidor local:

```bash
python3 -m http.server 5173
```

## Deploy Firebase

```bash
npm install -g firebase-tools
firebase login
cp .firebaserc.example .firebaserc
# edite .firebaserc com o projectId real
firebase deploy --only firestore:rules,firestore:indexes,storage,hosting
```

## Documentação

Veja `docs/FIREBASE.md`.

## Próxima mudança recomendada

Criar Cloud Functions para distribuir XP/MMR depois do resultado validado.
